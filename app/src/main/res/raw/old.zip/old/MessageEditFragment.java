package com.a_caring_reminder.app.message;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.a_caring_reminder.app.R;
import com.a_caring_reminder.app.acrDB;
import com.a_caring_reminder.app.acrQuery;


/*
 * Created by justin on 6/10/14.
 */
public class MessageEditFragment extends Fragment {

    private static final String TAG = "MessageEditFragment";
    public static final String ARG_ITEM_ID = "MessageEditFragment"; //was "item_id";

    private acrDB acrDB;
    private Callback mCallback;
    private String mItem;

    private Button mCancelButton;
    private Button mSaveButton;
    private EditText mSuppMsgEText;


    public interface Callback {
        public void onSupportMessageComplete();
    }

    /*
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */

    public MessageEditFragment() {

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mCancelButton = (Button) getActivity().findViewById(R.id.editMsgCncl);
        mSaveButton = (Button) getActivity().findViewById(R.id.editMsgSv);
        mSuppMsgEText = (EditText) getActivity().findViewById(R.id.addMsgEdTxt);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_message_edit, container, false);


        return view;
    }

    @Override
    public void onStart() {
        super.onStart();


        mSaveButton.setOnClickListener(saveMessageListener);
        mCancelButton.setOnClickListener(cancelMessageListener);
    }


    //
    // Event Listeners
    //

    private View.OnClickListener cancelMessageListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //
            // TODO implement callback here
            //

            mCallback.onSupportMessageComplete();


        }
    };


    private View.OnClickListener saveMessageListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            //
            //  Get message from current message view
            //


            String suppMsgText = "";
            //
            // getText().toString to capture entered text into
            // EditText (@link R.id.addMsgEdTxt)

            if(mSuppMsgEText.getText().toString() != null) {
                suppMsgText = mSuppMsgEText.getText().toString();
            }else{
                Log.e("Null Value for ", mSuppMsgEText.getText().toString());
                return;
            }

            //
            // Using SharedPreferences for V1
            //
            //acrDB acrDB;
            //sharedPrefEdit.putString(Constants.SAVE_SUPP_MSG_KEY, suppMsgText);
            //sharedPrefEdit.commit();


            //
            // Save that to the database
            //






            //
            //TODO implement callback here when edit MessageListFragment is created
            //

            mCallback.onSupportMessageComplete();
        }
    };


    @Override
    public void onAttach(Activity activity) {

        super.onAttach(activity);
        // Activities containing this fragment must implement its callbacks.
        if (!(activity instanceof Callback)) {
            throw new IllegalStateException("Activity must implement fragment's callbacks.");
        }

        mCallback = (Callback) activity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Create the database here so that it gets the Activity Context.
        acrDB = new acrDB(getActivity());
        acrQuery query = new acrQuery(acrDB);

        if (getArguments().containsKey(ARG_ITEM_ID)) {
            // Load the content using a query with an id specified by the fragment
            mItem = query.getSupportMessageDetail(getArguments().getString(ARG_ITEM_ID));
        }
    }


}


