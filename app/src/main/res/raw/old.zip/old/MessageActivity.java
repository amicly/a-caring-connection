package com.a_caring_reminder.app.message;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.a_caring_reminder.app.R;


/**
 * An activity representing a list of messages. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of messages, which when touched,
 * lead to a {@link MessageActivity} representing
 * message edits. On tablets, the activity presents the list of messages and
 * message edits side-by-side using two vertical panes.
 * <p>
 * The activity makes heavy use of fragments. The list of messages is a
 * {@link MessageListFragment} and the Messages Edit
 * (if present) is a {@link MessageEditFragment}.
 * <p>
 * This activity also implements the required
 * {@link MessageListFragment.Callbacks} interface
 * to listen for message selections.
 */
public class MessageActivity extends FragmentActivity
        implements MessageListFragment.Callbacks , MessageEditFragment.Callback{

    private static final String TAG = "MessageActivity";

    /*
     * Whether or not the activity is in two-pane mode, i.e. running on a tablet
     * device.
     */

    private boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
//        if (findViewById(R.id.container) != null) {
//            if (savedInstanceState != null) {
//                return;
//            }
//            FoodTruckListViewFragment foodTruckListViewFragment = new FoodTruckListViewFragment();
//            foodTruckListViewFragment.setArguments(getIntent().getExtras());
//
//            getSupportFragmentManager().beginTransaction()
//                    .add(R.id.container, new FoodTruckListViewFragment())
//                    .commit();
//        }

        if (findViewById(R.id.message_list) != null) {
            // The detail container view will be present only in the
            // large-screen layouts
            // res/layout-sw600dp). If this view is present, then the
            // activity should be in two-pane mode.
            mTwoPane = true;

            // In two-pane mode, list items should be given the
            // 'activated' state when touched.
            ((MessageListFragment) getFragmentManager()
                    .findFragmentById(R.id.message_list))
                    .setActivateOnItemClick(true);
        }

        if (findViewById(R.id.message_list) != null) {
            if (savedInstanceState != null) {
                return;
            }

            displayMessageListFragment();
            Toast.makeText(getApplicationContext(), "onCreate in MessageListFragmentCreated", Toast.LENGTH_SHORT).show();
        }

        Toast.makeText(getApplicationContext(), "onCreate in MessageActivity", Toast.LENGTH_SHORT).show();

        // TODO: If exposing deep links into your app, handle intents here.
    }

    /**
     * Callback method from {@link MessageListFragment.Callbacks}
     * indicating that the item with the given ID was selected.
     */

    @Override
    public void onItemSelected(String id) {
        if (mTwoPane) {
            // In two-pane mode, show the detail view in this activity by
            // adding or replacing the detail fragment using a
            // fragment transaction.
            Bundle arguments = new Bundle();
            arguments.putString(MessageEditFragment.ARG_ITEM_ID, id);
            MessageEditFragment fragment = new MessageEditFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.message_list, fragment)
                    .commit();

        } else {
            //Otherwise we are in single pane mode.
            Bundle arguments = new Bundle();
            arguments.putString(MessageEditFragment.ARG_ITEM_ID, id);
            MessageEditFragment fragment = new MessageEditFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.message_edit_container, fragment)
                    .commit();

        }
    }

    /*
     * Callback method from MessageEditFragment.Callback
     * indicating that the item was either saved or cancelled
     */

    @Override
    public void onSupportMessageComplete() {
        //item was saved or cancelled
        displayMessageListFragment();
    }

    /*
    *  method to display MessageListFragment
    */
    private void displayMessageListFragment(){
        Fragment messageListFragment = new Fragment();
        android.support.v4.app.FragmentTransaction fragTransaction = getSupportFragmentManager().beginTransaction();
        fragTransaction.replace(R.id.message_list_container, messageListFragment);
        fragTransaction.addToBackStack(null);
        fragTransaction.commit();
    }

    /*
    *  method to display MessageEditFragment
    */
    private void displayMessageEditFragment(){
        android.support.v4.app.Fragment messageEditFragment = new MessageEditFragment();
        android.support.v4.app.FragmentTransaction fragTransaction = getSupportFragmentManager().beginTransaction();
        fragTransaction.replace(R.id.message_edit_container, messageEditFragment);
        fragTransaction.addToBackStack(null);
        fragTransaction.commit();
    }

//    private void displayNewMessageListFragment(){
//        MessageListFragment foodTruckListViewFragment = new MessageListFragment();
//        foodTruckListViewFragment.setArguments(getIntent().getExtras());
//
//        getSupportFragmentManager().beginTransaction()
//                .add(R.id.message_list, new MessageListFragment())
//                .commit();
//    }


}
